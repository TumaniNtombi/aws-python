print("Count to 11!")
for x in range (0, 12):
    print(x)